# Instalação do Chatwoot e Evolution API

Este diretório contém arquivos de configuração e scripts para instalar o Chatwoot e a Evolution API em um ambiente Docker Swarm.

## Arquivos de Configuração

- `1 - traefik.yaml`: Configuração do Traefik (proxy reverso)
- `2 - portainer.yaml`: Configuração do Portainer (gerenciamento de contêineres)
- `3 - redis.yaml`: Configuração do Redis (cache)
- `4 - postgres.yaml`: Configuração do PostgreSQL (banco de dados)
- `5 - chatwoot_v4.yaml`: Configuração do Chatwoot v4.0.3
- `6 - evolutionV2.yaml`: Configuração da Evolution API v2.2.3

## Scripts

- `instalar.sh`: Script para remover a instalação atual e configurar uma nova
- `verificar_status.sh`: Script para verificar o status dos serviços
- `configurar_integracao.sh`: Script para configurar a integração entre o Chatwoot e a Evolution API

## Pré-requisitos

- Docker Swarm inicializado
- Domínios configurados para apontar para o servidor:
  - chat.sprintia.com.br
  - evolution.sprintia.com.br
- Portas 80 e 443 abertas no firewall

## Instruções de Instalação

1. Verifique e ajuste as configurações nos arquivos YAML conforme necessário
2. Execute o script de instalação:

```bash
./instalar.sh
```

3. Após a instalação, configure o Chatwoot:

```bash
docker exec -it $(docker ps | grep chatwoot_app | awk '{print $1}') bundle exec rails db:chatwoot_prepare
```

4. Verifique o status dos serviços:

```bash
./verificar_status.sh
```

5. Configure a integração entre o Chatwoot e a Evolution API:

```bash
./configurar_integracao.sh
```

## Acesso

- Chatwoot: https://chat.sprintia.com.br
- Evolution API: https://evolution.sprintia.com.br

## Solução de Problemas

Se encontrar problemas com a conexão do WhatsApp:

1. Verifique os logs dos contêineres:
   ```bash
   docker logs $(docker ps | grep evolution_v2 | awk '{print $1}')
   ```

2. Certifique-se de que as configurações de integração estão corretas
3. Tente recriar a instância do WhatsApp usando o script `configurar_integracao.sh`

## Observações

- A senha do PostgreSQL está definida como `SprintiaDB2024!`
- A chave da API da Evolution está definida como `sprintia-evolution-api-key`
- Você precisará obter um token de API do Chatwoot para configurar a integração
